# faultylambdasensor
Python Package for determining the Air:Fule Ratio from the Fule Maps and Spark Angle from the Ignition Map for the Faulty Lambda Sensor
