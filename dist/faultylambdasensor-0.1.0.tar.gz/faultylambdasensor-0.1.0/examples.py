from faultylambdasensor import FLS

print(FLS.airfuelratio(load=150, rpm=1500))
print(FLS.lambdavalue(load=150, rpm=1500))
print(FLS.sparkangle(load=150, rpm=1500))
